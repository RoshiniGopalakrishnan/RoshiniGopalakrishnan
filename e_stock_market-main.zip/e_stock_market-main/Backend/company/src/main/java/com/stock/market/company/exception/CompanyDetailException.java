package com.stock.market.company.exception;

/**
 * @author Ksp
 *
 */
public class CompanyDetailException extends Exception {
	public CompanyDetailException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
